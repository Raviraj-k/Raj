﻿
namespace Visitor_mangt.Entities
{
    public class Entities
    {
		public class VisitorRequest
		{
			public string Id { get; set; }
			public string VisitorName { get; set; }
			public string VisitorEmail { get; set; }
			public bool IsApproved { get; set; }
		}
		public class User
		{
			public string Id { get; set; }
			public string Name { get; set; }
			public string Email { get; set; }
			// Other properties based on user role
		}

		

	}
}
