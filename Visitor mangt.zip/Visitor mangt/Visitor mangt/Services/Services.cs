﻿using static Visitor_mangt.Services.Services;
using Visitor_mangt.DTO;
using Visitor_mangt.Interfaces;
using System.ComponentModel;

namespace Visitor_mangt.Services
{
    public class Services
    {
        public class UserService : IUserService

        {
            public interface IUserService
            {
               IUserService Authenticate(string username, string password);
                // Other methods for user management (e.g., registration, updating user details)
            }

            public class IUserService : IUserService
            {
                private readonly IUserRepository _userRepository;

                public UserService(IUserRepository userRepository)
                {
                    _userRepository = userRepository;
                }

                public User Authenticate(string username, string password)
                {
                    // Validate input parameters
                    if (string.IsNullOrEmpty(username) || string.IsNullOrEmpty(password))
                    {
                        return null;
                    }

                    // Retrieve user from the repository based on the username
                    User user = _userRepository.GetUserByUsername(username);

                    // Check if the user exists and the password matches
                    if (user != null && VerifyPassword(password, user.Password))
                    {
                        // Clear sensitive information before returning the user object
                        user.ClearSensitiveData();
                        return user;
                    }

                    return null; // Authentication failed
                }

                // Additional methods for user management can be added here
                // (e.g., RegisterUser, UpdateUser, GetUserById, etc.)

                private bool VerifyPassword(string inputPassword, string hashedPassword)
                {
                    // Implement password verification logic (e.g., using a secure hashing algorithm)
                    // For simplicity, this example assumes plain text comparison.
                    return inputPassword == hashedPassword;
                }
            }

            // Implementation for user service
        }

        public class RequestService : IRequestService
        {
            
            // Implementation for request service
        }

        private  Container GetContainer()
        {
            string URL = Environment.GetEnvironmentVariable("Cosmos-URL");
            string Primarykey  = Environment.GetEnvironmentVariable("Primary Key");
            string DatabaseName = Environment.GetEnvironmentVariable("Database Name");
            string ContainerName = Environment.GetEnvironmentVariable("Container Name");
        }
    }
}
