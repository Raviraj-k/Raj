﻿using Visitor_mangt.Services;
using Visitor_mangt.Interfaces;
namespace Visitor_mangt.DTO;

public class DTO
{
    public class VisitorRequestDTO
    {
        public string VisitorID { get; set; }
        public string VisitorName { get; set; }
        public string VisitorEmail { get; set; }
        public string VisitorPassward { get; set; }
        // Other request details
    }
    

   

    // Entities
    public class VisitorEntity
    {
        public string Id { get; set; }
        public string Name { get; set; }
        public string Email { get; set; }
        // ... other properties
    }

    public class RequestEntity
    {
        public string Id { get; set; }
        public VisitorEntity Visitor { get; set; }
        public bool IsApproved { get; set; }
        // ... other properties
    }
}
