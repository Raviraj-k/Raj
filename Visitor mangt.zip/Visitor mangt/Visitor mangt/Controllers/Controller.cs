﻿using Microsoft.AspNetCore.Mvc;
using Visitor_mangt.DTO;
using Visitor_mangt.Interfaces;
using Visitor_mangt.Services;



namespace Visitor_mangt.Controllers
{
    public class Controller
    {
        [Route("api/[controller]")]
        [ApiController]
        public class UserController : ControllerBase
        {
            public Interfaces.Interfaces.IUserService Centra;

            public UserController(Interfaces.Interfaces.IUserService userService)
            {
                Centra = userService;
            }

            [HttpPost("authenticate")]
            public IActionResult Authenticate(user user)
            {
                user.username = "Centra";
                user.passward = 0000;

                // Implementation for user authentication
                // You can access user properties like user.Username and user.Password here
            }

        }

        [Route("api/[controller]")]
        [ApiController]
        public class RequestController : ControllerBase
        {
            private readonly IRequestService _requestService;

            public RequestController(IRequestService requestService)
            {
                _requestService = requestService;
            }

            [HttpPost("submit")]
            public IActionResult SubmitRequest([FromBody] VisitorRequestDTO requestDTO)
            {
                // Implementation for submitting a request
            }

            // Other endpoints for managing requests
        }

    }

    public class user
    {
        internal string username;
        internal int passward;
    }
}
