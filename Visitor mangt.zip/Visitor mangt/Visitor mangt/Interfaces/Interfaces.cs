﻿using Visitor_mangt.DTO;
using Visitor_mangt.Controllers;
using Visitor_mangt.Services;


namespace Visitor_mangt.Interfaces
{
    public class Interfaces
    {
        public interface IRequestServices
        {
            void SubmitRequest(VisitorRequestDTO requestDTO);
            IEnumerable<VisitorRequest> GetRequests();
            void ApproveRequest(string requestId);
            void RejectRequest(string requestId);
        }

        public interface IEmailService
        {
            void SendVerificationEmail(string to, string subject, string body);
        }

    }

    public class VisitorRequest
    {

        public string Id { get; set; }
        public string VisitorName { get; set; }
        // Other request details
    }

    public class VisitorRequestDTO
    {
        public string VisitorName { get; set; }
        public string VisitorEmail { get; set; }
        public string VisitorPassward { get; set; }
    }
}
